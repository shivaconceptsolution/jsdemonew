function fun()
{
s = "Welcome in JS"
alert(s);
}

function changeColor()
{
    document.getElementById("body").style.backgroundColor="Cyan";
}